import * as types from './mutation-types'

// export const logIn = ({ commit }) => {
//   commit(types.LOG_IN)
// }

// export const startListeningToAuth = ({ commit }) => {
//   commit(types.LISTEN_AUTH)
// }
