export const route = state => {
  return state.route
}
export const routePath = state => {
  return state.route.path
}
